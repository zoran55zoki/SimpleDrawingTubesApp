﻿



using HelixToolkit.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Controls.Primitives;
using System.ComponentModel;
using System.Timers;
using System.Windows.Input;
using System.Collections.Specialized;

namespace WPFObjectsAppTest
{
    class Tube : UIElement3D, INotifyCollectionChanged
    {

        private readonly Timer _timer;
        private readonly ToolTip _toolTip;

        public Tube DataContext { get; }
        public Material materialtype;
        public double diameter;
        public string tubeName1;
        public Point3DCollection tubePath;
        public Point3DCollection GetTubePath
        {
            get { return tubePath; }
        }
        public Material Texture { get { return materialtype; } set { materialtype = value; } }

        public Tube(Point3DCollection path, string tubeName, double diametar_1, int thetaDiv, Material material)
        {
            MeshBuilder builder = new MeshBuilder();

            tubePath = path;
        
            List<Point3D> list = new List<Point3D>();

            for (int i = 0; i < path.Count; i++)
            {

                list.Add(path[i]);

            }           

            list = CanonicalSplineHelper.CreateSpline(list, 0.5, null, false, 0.01); 
            
            
            builder.AddTube(list, diametar_1, thetaDiv, false, true, true);

            diameter = diametar_1;
            tubeName1 = tubeName;
          


            GeometryModel3D model = new GeometryModel3D(builder.ToMesh(), material);
          
            model.SetName(tubeName);
            Visual3DModel = model;
            materialtype = material;
          
            _toolTip = new ToolTip();
         
            _timer = new Timer { AutoReset = false };
            _timer.Elapsed += ShowToolTip;

            DataContext = this;
        }




        public event NotifyCollectionChangedEventHandler CollectionChanged
        {
            add
            {
                ((INotifyCollectionChanged)DataContext).CollectionChanged += value;
            }

            remove
            {
                ((INotifyCollectionChanged)DataContext).CollectionChanged -= value;
            }
        }

        public object ToolTipContent { get { return _toolTip.Content; } set { _toolTip.Content = value; } }

      
        private void ShowToolTip(object sender, ElapsedEventArgs e)
        {
            _timer.Stop();
            if (_toolTip != null)
                _toolTip.Dispatcher.Invoke(new Action(() => { _toolTip.IsOpen = true; }));
        }

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);

            var gm = Visual3DModel as GeometryModel3D;



            gm.Material = gm.Material == materialtype ? Materials.Yellow : materialtype;


            if (_toolTip != null)
            {
                _toolTip.IsOpen = true;
                _toolTip.Content = gm.GetName().ToString().Trim() + " tube";
            }
      
            _timer.Interval = 50;
            _timer.Start();

            e.Handled = true;
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);

            var gm = Visual3DModel as GeometryModel3D;
            gm.Material = gm.Material == materialtype ? Materials.Yellow : materialtype;

            _timer.Stop();
            if (_toolTip != null)
            {
                _toolTip.IsOpen = false;
                _toolTip.Content = "";
            }


            e.Handled = true;

        }





    }
}

