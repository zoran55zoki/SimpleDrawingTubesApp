﻿


using HelixToolkit.Wpf;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace WPFObjectsAppTest
{
    class TransparentCylinder : UIElement3D, INotifyCollectionChanged
    {


       public TransparentCylinder()
        {
        }

        public TransparentCylinder(Point3D p1,Point3D p2, double diameter)
        {
            MeshBuilder builder = new MeshBuilder();





            builder.AddCylinder(p1, p2, diameter, 32,true,true);


            SolidColorBrush cb = new SolidColorBrush();
            cb.Opacity = 0.5;

            cb.Color = new Color()
            {
                A = 50, //transparency level indicator
                R = Colors.Transparent.R,
                G = Colors.Transparent.G,
                B = Colors.Transparent.B
            };

            DiffuseMaterial dm = new DiffuseMaterial(cb);


            GeometryModel3D model = new GeometryModel3D(builder.ToMesh(), dm);

            model.Material = new DiffuseMaterial(cb);
            model.BackMaterial = new DiffuseMaterial(cb);
            model.SetName("TransparentCylinder");

            Visual3DModel = model;

        }

        public event NotifyCollectionChangedEventHandler CollectionChanged;
    }
}